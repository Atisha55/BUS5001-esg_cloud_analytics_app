const rules = {
  classify(message) {
    const m = message.toLowerCase();
    let category = 'General ESG inquiry', urgency = 'LOW', team = 'ESG Operations', sensitivity = 'LOW', reason = 'Standard ESG request';
    if (m.includes('leak') || m.includes('water')) { category = 'Water / Facilities'; urgency = m.includes('all morning') || m.includes('running') ? 'HIGH' : 'MEDIUM'; team = 'Facilities Emergency'; reason = 'Active water issue may create safety or property damage risk'; }
    if (m.includes('accessible') || m.includes('blocked') || m.includes('entrance')) { category = 'Accessibility and Inclusion'; urgency = 'HIGH'; team = 'Inclusion and Facilities'; sensitivity = 'MEDIUM'; reason = 'Blocked access creates exclusion and safety risk'; }
    if (m.includes('supplier') || m.includes('procurement')) { category = 'Sustainable Procurement'; urgency = 'MEDIUM'; team = 'Procurement Governance'; sensitivity = 'MEDIUM'; reason = 'Potential policy non-compliance requires review'; }
    if (m.includes('recycling') || m.includes('bins') || m.includes('contaminated')) { category = 'Waste and Recycling'; urgency = 'MEDIUM'; team = 'Waste Services'; reason = 'Contamination affects sustainability reporting and disposal costs'; }
    if (m.includes('air conditioning') || m.includes('overnight') || m.includes('energy')) { category = 'Energy Efficiency'; urgency = 'MEDIUM'; team = 'Energy Management'; reason = 'Ongoing energy waste may increase emissions and costs'; }
    return {
      issue_category: category,
      urgency,
      sentiment: m.includes('again') || m.includes('no one') || m.includes('blocked') ? 'NEGATIVE' : 'NEUTRAL',
      followup_required: urgency === 'LOW' ? 'N' : 'Y',
      recommended_team: team,
      escalation_reason: reason,
      data_sensitivity_risk: sensitivity,
      brief_summary: message.length > 115 ? message.slice(0, 112) + '...' : message
    };
  },
  baseline(message) {
    const m = message.toLowerCase();
    if (m.includes('leak')) return { issue_category:'Water / Facilities', urgency:'HIGH', recommended_team:'Facilities Emergency' };
    if (m.includes('recycling') || m.includes('bins')) return { issue_category:'Waste and Recycling', urgency:'MEDIUM', recommended_team:'Waste Services' };
    if (m.includes('supplier')) return { issue_category:'Sustainable Procurement', urgency:'MEDIUM', recommended_team:'Procurement Governance' };
    if (m.includes('air conditioning') || m.includes('energy')) return { issue_category:'Energy Efficiency', urgency:'MEDIUM', recommended_team:'Energy Management' };
    return { issue_category:'General ESG inquiry', urgency:'LOW', recommended_team:'ESG Operations' };
  }
};
function renderTriage(){
  const msg = document.getElementById('messageInput').value;
  const llm = rules.classify(msg);
  const baseline = rules.baseline(msg);
  document.getElementById('triageJson').textContent = JSON.stringify(llm, null, 2);
  const rows = ['issue_category','urgency','recommended_team'];
  const tbody = document.querySelector('#baselineTable tbody');
  tbody.innerHTML = rows.map(k => `<tr><td>${k}</td><td>${llm[k]}</td><td>${baseline[k]}</td><td>${llm[k]===baseline[k]?'Yes':'No'}</td></tr>`).join('');
}
document.getElementById('triageBtn').addEventListener('click', renderTriage);
renderTriage();
